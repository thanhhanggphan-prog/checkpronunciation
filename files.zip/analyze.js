// ============================================================
//  analyze.js — Parse dialogue & detect vocab / grammar
// ============================================================

/**
 * Parse raw dialogue text into line objects.
 * @param {string} raw
 * @returns {{ isA: boolean, text: string }[]}
 */
function parseDialogue(raw) {
  return raw
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean)
    .map(l => {
      const isA = /^A\s*:/i.test(l);
      const text = l.replace(/^[AB]\s*:\s*/i, '').trim();
      return { isA, text };
    });
}

/**
 * Scan the dialogue for known vocabulary words.
 * @param {string} fullText - all lines joined
 * @returns vocab entries from VOCAB_DB that appear in the text
 */
function detectVocab(fullText) {
  const lower = fullText.toLowerCase();
  return VOCAB_DB.filter(v => {
    const re = new RegExp(`\\b${v.word}\\b`, 'i');
    return re.test(lower);
  });
}

/**
 * Scan the dialogue for known grammar patterns.
 * @param {string} fullText
 * @returns grammar entries from GRAMMAR_DB that appear in the text,
 *          each augmented with `.exampleSentence` (the first matching line)
 */
function detectGrammar(fullText, lines) {
  return GRAMMAR_DB
    .filter(g => {
      g.pattern.lastIndex = 0;
      const found = g.pattern.test(fullText);
      g.pattern.lastIndex = 0;
      return found;
    })
    .map(g => {
      const matchedLine = lines.find(l => {
        g.pattern.lastIndex = 0;
        const r = g.pattern.test(l.text);
        g.pattern.lastIndex = 0;
        return r;
      });
      return { ...g, exampleSentence: matchedLine ? matchedLine.text : g.formula };
    });
}

/**
 * Master analysis function.
 * @param {{ isA: boolean, text: string }[]} lines
 * @returns {{ vocab, grammar }}
 */
function analyzeLines(lines) {
  const fullText = lines.map(l => l.text).join(' ');
  return {
    vocab:   detectVocab(fullText),
    grammar: detectGrammar(fullText, lines),
  };
}
