# English Dialogue Learning

Ứng dụng học tiếng Anh qua hội thoại — chạy hoàn toàn trên trình duyệt, **không cần server, không cần API key**.

## Tính năng

| Tính năng | Mô tả |
|-----------|-------|
| 🎙️ Phát âm 2 giọng | Giọng A (nữ) & B (nam) riêng biệt — Web Speech API |
| 🟣 Highlight từ vựng | Tô màu tím, bấm để nghe phát âm |
| 🟢 Highlight ngữ pháp | Tô màu xanh, bấm để nghe **cả câu** chứa cấu trúc |
| 📖 Từ điển mini | Phiên âm, từ loại, nghĩa, câu ví dụ + nút nghe |
| 📐 Ngữ pháp | Công thức, mẹo dùng, câu ví dụ + nút nghe câu |
| 🔊 Tên cấu trúc | Nút nghe tên ngữ pháp ("Present Perfect", "Look forward to"…) |
| 🤖 Roleplay thông minh | Luyện hội thoại với AI đóng vai đối diện, có phản hồi |
| 👥 Tên nhân vật tự do | Đặt tên A & B tùy ý |

## Cách dùng

1. Mở `index.html` trong trình duyệt (Chrome hoặc Edge cho chất lượng giọng tốt nhất)
2. Nhập tên nhân vật A và B
3. Nhập hội thoại theo định dạng:
   ```
   A: Hi! Have you finished the project?
   B: Not yet. I've been working on it all day.
   ```
4. Nhấn **Phân tích hội thoại**

## Cấu trúc dự án

```
english-dialogue-learning/
├── index.html          # Giao diện chính
├── css/
│   └── style.css       # Toàn bộ CSS (light + dark mode)
├── js/
│   ├── data.js         # Cơ sở dữ liệu từ vựng & ngữ pháp
│   ├── speech.js       # Web Speech API wrapper
│   ├── analyze.js      # Phân tích văn bản
│   ├── render.js       # Render DOM & highlight
│   ├── roleplay.js     # Hệ thống roleplay
│   └── app.js          # Controller chính
└── README.md
```

## Mở rộng

### Thêm từ vựng
Mở `js/data.js` và thêm vào mảng `VOCAB_DB`:
```js
{ word: 'negotiate', phonetic: '/nɪˈɡəʊ.ʃi.eɪt/', type: 'v.', meaning: 'đàm phán', example: 'We need to negotiate the terms.' },
```

### Thêm cấu trúc ngữ pháp
Thêm vào mảng `GRAMMAR_DB`:
```js
{
  name:    'Used to',
  pattern: /\bused\s+to\b/gi,
  formula: 'S + used to + V (bare infinitive)',
  tip:     'Dùng để nói về thói quen hoặc trạng thái trong quá khứ, nay không còn nữa.',
},
```

## Yêu cầu

- Trình duyệt hiện đại có hỗ trợ [Web Speech API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API)
- **Chrome / Edge**: tốt nhất (nhiều giọng đọc nhất)
- **Firefox / Safari**: hoạt động nhưng ít giọng hơn
- Không cần cài đặt, không cần internet (trừ icon font từ jsDelivr)

## Deploy lên GitHub Pages

1. Push thư mục này lên GitHub repository
2. Vào **Settings → Pages → Source**: chọn branch `main`, folder `/` (root)
3. GitHub Pages sẽ serve `index.html` tự động

## License

MIT
