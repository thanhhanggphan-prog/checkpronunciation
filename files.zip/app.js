// ============================================================
//  app.js — Main controller: wires everything together
// ============================================================

// Global state
let _lines    = [];
let _isPlaying = false;
let _playIdx  = 0;

// ---- Analyse & render ----

function analyzeDialogue() {
  const raw   = document.getElementById('dialogueInput').value.trim();
  const nameA = document.getElementById('nameA').value.trim() || 'A';
  const nameB = document.getElementById('nameB').value.trim() || 'B';

  if (!raw) { showToast('Vui lòng nhập hội thoại trước!'); return; }

  _lines = parseDialogue(raw);
  if (!_lines.length) { showToast('Không nhận diện được hội thoại. Dùng định dạng A: ... / B: ...'); return; }

  const analysis = analyzeLines(_lines);
  window._currentAnalysis = analysis; // expose for onclick handlers in render.js

  renderDialogue(_lines, nameA, nameB, analysis);
  renderVocab(analysis.vocab);
  renderGrammar(analysis.grammar);

  document.getElementById('mainContent').style.display = 'block';
  document.getElementById('mainContent').scrollIntoView({ behavior: 'smooth', block: 'start' });

  Roleplay.init(_lines, nameA, nameB);
}

// ---- Play all lines sequentially ----

function playAll() {
  if (_isPlaying) { stopAll(); return; }
  stopAll();
  _isPlaying = true;
  _playIdx   = 0;

  document.getElementById('playAllBtn').innerHTML = '<i class="ti ti-player-stop"></i> Đang phát...';
  playNextLine();
}

function playNextLine() {
  if (!_isPlaying || _playIdx >= _lines.length) {
    stopAll();
    return;
  }
  document.querySelectorAll('.line-block').forEach(b => b.classList.remove('playing'));
  const el = document.getElementById('line-' + _playIdx);
  if (el) el.classList.add('playing');

  const line = _lines[_playIdx];
  Speech.speak(line.text, line.isA, () => {
    _playIdx++;
    setTimeout(playNextLine, 450);
  });
}

function stopAll() {
  Speech.stop();
  _isPlaying = false;
  _playIdx   = 0;
  document.querySelectorAll('.line-block').forEach(b => b.classList.remove('playing'));
  const btn = document.getElementById('playAllBtn');
  if (btn) btn.innerHTML = '<i class="ti ti-player-play"></i> Phát tất cả';
}

// ---- Helpers ----

function loadSample() {
  document.getElementById('nameA').value = 'Anna';
  document.getElementById('nameB').value = 'Ben';
  document.getElementById('dialogueInput').value =
`A: Hi Ben! Have you finished the project yet?
B: Not yet. I've been working on it since Monday.
A: I look forward to seeing your results soon.
B: Thanks! I'm really excited about presenting it.
A: Have you considered adding more visuals?
B: Yes, I've already prepared some charts.`;
}

function clearAll() {
  stopAll();
  document.getElementById('dialogueInput').value = '';
  document.getElementById('nameA').value = 'A';
  document.getElementById('nameB').value = 'B';
  document.getElementById('mainContent').style.display = 'none';
  window._currentAnalysis = null;
  _lines = [];
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 2800);
}

// Auto-load sample on first open so users immediately see how it works
window.addEventListener('DOMContentLoaded', loadSample);
