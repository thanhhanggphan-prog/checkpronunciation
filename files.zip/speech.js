// ============================================================
//  speech.js — Web Speech API wrapper
// ============================================================

const Speech = (() => {
  const synth = window.speechSynthesis;
  let voices = [];
  let voiceA = null; // speaker A (female)
  let voiceB = null; // speaker B (male)

  function loadVoices() {
    voices = synth.getVoices();
    const eng = voices.filter(v => v.lang.startsWith('en'));
    if (!eng.length) return;

    voiceA = eng.find(v => /female|zira|samantha|karen|moira|victoria|fiona|lisa/i.test(v.name))
           || eng[0];
    voiceB = eng.find(v => /male|david|daniel|alex|rishi|oliver|fred|james|george/i.test(v.name))
           || eng[1]
           || eng[0];
  }

  loadVoices();
  if (speechSynthesis.onvoiceschanged !== undefined) {
    speechSynthesis.onvoiceschanged = loadVoices;
  }

  /**
   * Speak a text string.
   * @param {string}   text   - The text to speak
   * @param {boolean}  isA    - true = voice A (female), false = voice B (male)
   * @param {Function} onEnd  - Optional callback when speech ends
   */
  function speak(text, isA = true, onEnd = null) {
    synth.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    utt.voice  = isA ? voiceA : voiceB;
    utt.rate   = 0.9;
    utt.pitch  = isA ? 1.1 : 0.9;
    utt.lang   = 'en-US';
    if (onEnd) utt.onend = onEnd;
    synth.speak(utt);
  }

  function stop() {
    synth.cancel();
  }

  return { speak, stop };
})();
