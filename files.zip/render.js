// ============================================================
//  render.js — Build all DOM elements from analysis data
// ============================================================

// Escape HTML entities
function escHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Escape for HTML attribute (single-quote safe)
function escAttr(s) {
  return String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '&quot;');
}

/**
 * Apply vocabulary + grammar highlights to a line of text.
 * Grammar spans get an onclick that plays the whole sentence.
 * Vocab spans get an onclick that plays the word.
 */
function highlightLine(text, vocab, grammar) {
  const marks = [];

  // Collect grammar marks first (higher priority)
  grammar.forEach((g, gi) => {
    const re = new RegExp(g.pattern.source, g.pattern.flags.replace('g', '') + 'g');
    let m;
    while ((m = re.exec(text)) !== null) {
      marks.push({ start: m.index, end: m.index + m[0].length, type: 'grammar', index: gi, matched: m[0] });
    }
  });

  // Collect vocab marks (skip overlaps with grammar)
  vocab.forEach((v, vi) => {
    const re = new RegExp(`\\b${v.word}\\b`, 'gi');
    let m;
    while ((m = re.exec(text)) !== null) {
      const overlap = marks.some(mk => m.index < mk.end && (m.index + m[0].length) > mk.start);
      if (!overlap) {
        marks.push({ start: m.index, end: m.index + m[0].length, type: 'vocab', index: vi, matched: m[0] });
      }
    }
  });

  // Sort by position
  marks.sort((a, b) => a.start - b.start);

  let out = '';
  let pos = 0;
  marks.forEach(mk => {
    if (mk.start < pos) return; // skip overlaps
    out += escHtml(text.slice(pos, mk.start));
    if (mk.type === 'vocab') {
      out += `<span class="vocab-hl" onclick="onVocabClick(${mk.index})" title="${escHtml(vocab[mk.index].meaning)}">${escHtml(mk.matched)}</span>`;
    } else {
      out += `<span class="grammar-hl" onclick="onGrammarClick(this,'${escAttr(text)}')" title="${escHtml(grammar[mk.index].name)} — bấm để nghe câu">${escHtml(mk.matched)}</span>`;
    }
    pos = mk.end;
  });
  out += escHtml(text.slice(pos));
  return out;
}

/**
 * Render dialogue lines into #dialogueLines.
 */
function renderDialogue(lines, nameA, nameB, analysis) {
  const container = document.getElementById('dialogueLines');
  container.innerHTML = '';
  lines.forEach((line, i) => {
    const name = line.isA ? nameA : nameB;
    const cls  = line.isA ? 'sp-a' : 'sp-b';
    const icon = line.isA ? 'ti-user' : 'ti-user-circle';
    const hl   = highlightLine(line.text, analysis.vocab, analysis.grammar);

    const div = document.createElement('div');
    div.className = 'line-block';
    div.id = `line-${i}`;
    div.innerHTML = `
      <div class="speaker-label ${cls}">
        <i class="ti ${icon}" aria-hidden="true"></i> ${escHtml(name)}
        <button class="btn btn-sm speak-btn-inline" onclick="Speech.speak('${escAttr(line.text)}', ${line.isA})" title="Nghe dòng này">
          <i class="ti ti-volume" aria-hidden="true"></i>
        </button>
      </div>
      <div class="line-text">${hl}</div>`;
    container.appendChild(div);
  });
}

/**
 * Render vocabulary cards into #vocabList.
 */
function renderVocab(vocab) {
  const c = document.getElementById('vocabList');
  if (!vocab.length) {
    c.innerHTML = '<div class="empty-state">Không tìm thấy từ vựng nổi bật trong từ điển.</div>';
    return;
  }
  c.innerHTML = vocab.map(v => `
    <div class="vocab-item">
      <div class="vocab-word-row">
        <span class="vocab-word">${escHtml(v.word)}</span>
        <span class="vocab-type">${escHtml(v.type)}</span>
        <button class="mini-play" onclick="Speech.speak('${escAttr(v.word)}', true)" title="Nghe phát âm từ">
          <i class="ti ti-volume" aria-hidden="true"></i>
        </button>
      </div>
      <div class="vocab-phonetic">${escHtml(v.phonetic)}</div>
      <div class="vocab-meaning">${escHtml(v.meaning)}</div>
      <div class="vocab-example-row">
        <button class="mini-play" onclick="Speech.speak('${escAttr(v.example)}', true)" title="Nghe câu ví dụ">
          <i class="ti ti-player-play" aria-hidden="true"></i>
        </button>
        <span>${escHtml(v.example)}</span>
      </div>
    </div>`).join('');
}

/**
 * Render grammar cards into #grammarList.
 */
function renderGrammar(grammar) {
  const c = document.getElementById('grammarList');
  if (!grammar.length) {
    c.innerHTML = '<div class="empty-state">Không tìm thấy cấu trúc ngữ pháp trong cơ sở dữ liệu.</div>';
    return;
  }
  c.innerHTML = grammar.map(g => `
    <div class="gram-item">
      <div class="gram-name-row">
        <span class="gram-name">${escHtml(g.name)}</span>
        <button class="mini-play" onclick="Speech.speak('${escAttr(g.name)}', true)" title="Nghe tên cấu trúc">
          <i class="ti ti-volume" aria-hidden="true"></i>
        </button>
      </div>
      <div class="gram-formula">${escHtml(g.formula)}</div>
      ${g.tip ? `<div style="font-size:12px;color:var(--text-secondary);margin-bottom:5px">💡 ${escHtml(g.tip)}</div>` : ''}
      <div class="gram-example-row">
        <button class="mini-play" onclick="Speech.speak('${escAttr(g.exampleSentence)}', true)" title="Nghe câu ví dụ">
          <i class="ti ti-player-play" aria-hidden="true"></i>
        </button>
        <span>${escHtml(g.exampleSentence)}</span>
      </div>
    </div>`).join('');
}

// ---- Click handlers (called from inline onclick) ----

function onVocabClick(index) {
  if (!window._currentAnalysis) return;
  const v = window._currentAnalysis.vocab[index];
  if (v) Speech.speak(v.word, true);
}

function onGrammarClick(el, sentence) {
  document.querySelectorAll('.grammar-hl').forEach(g => g.classList.remove('playing-gram'));
  el.classList.add('playing-gram');
  Speech.speak(sentence, true, () => el.classList.remove('playing-gram'));
}
