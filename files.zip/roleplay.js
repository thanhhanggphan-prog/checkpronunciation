// ============================================================
//  roleplay.js — Smart Roleplay system
// ============================================================

const Roleplay = (() => {
  let context = [];    // { role: 'ai'|'user', text: string }[]
  let currentLines = [];
  let nameA = 'A';
  let nameB = 'B';
  let linePointer = 0; // tracks next expected dialogue line

  // Generic fallback responses when AI improvises
  const IMPROVISED = [
    'Great response! That sounded very natural. Let me continue the conversation.',
    'Well done! Your sentence structure was correct. Keep going!',
    "Excellent! You're doing really well. Here's my next line:",
    'Perfect! I noticed you used the grammar correctly. Nice work!',
    "That's a great way to say it! Let me reply:",
  ];

  function init(lines, nA, nB) {
    currentLines  = lines;
    nameA  = nA;
    nameB  = nB;
    context       = [];
    linePointer   = 0;

    const msgs = document.getElementById('rpMessages');
    msgs.innerHTML = '';

    // Find first A-line as opening
    const firstA = lines.find(l => l.isA);
    const opening = firstA
      ? `Xin chào! Tôi sẽ đóng vai **${nameA}**, bạn đóng vai **${nameB}**. Hãy trả lời câu của tôi nhé!\n\n"${firstA.text}"`
      : `Xin chào! Tôi sẽ đóng vai ${nameA}. Bạn đóng vai ${nameB}.`;

    addMessage(opening, false);
    if (firstA) Speech.speak(firstA.text, true);
    context.push({ role: 'ai', text: opening });

    document.getElementById('rpRole').textContent = `Bạn: ${nameB}`;
    document.getElementById('rpStatus').textContent = 'Nhập câu trả lời của bạn rồi nhấn Enter';

    // Attach Enter key listener (replace old one)
    const inp = document.getElementById('rpInput');
    inp.onkeydown = e => { if (e.key === 'Enter') sendMessage(); };
  }

  function addMessage(text, isUser) {
    const msgs = document.getElementById('rpMessages');
    const d = document.createElement('div');
    d.className = 'rp-msg ' + (isUser ? 'rp-user' : 'rp-ai');
    // Simple bold markdown: **text**
    d.innerHTML = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    msgs.appendChild(d);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function sendMessage() {
    const inp = document.getElementById('rpInput');
    const val = inp.value.trim();
    if (!val) return;

    addMessage(val, true);
    Speech.speak(val, false);
    inp.value = '';
    context.push({ role: 'user', text: val });

    // Advance pointer past the user's expected B-line
    while (linePointer < currentLines.length && currentLines[linePointer].isA) linePointer++;
    linePointer++; // skip the B-line the user just "said"

    // Now find the next A-line to continue
    setTimeout(() => generateReply(val), 700);
  }

  function generateReply(userText) {
    // Find next A-line in script
    const nextA = currentLines.slice(linePointer).find(l => l.isA);
    linePointer = currentLines.indexOf(nextA, linePointer) + 1;

    let feedback = '';
    // Simple correctness check: length and presence of at least one real word
    const wordCount = userText.split(/\s+/).filter(Boolean).length;
    if (wordCount < 2) {
      feedback = 'Hãy thử viết một câu đầy đủ hơn nhé! ';
    } else if (/\bi\b/i.test(userText) && /\b(have|'ve)\b/i.test(userText)) {
      feedback = 'Tuyệt! Bạn đã dùng Present Perfect rất tốt! ';
    } else if (wordCount >= 5) {
      feedback = `${IMPROVISED[Math.floor(Math.random() * IMPROVISED.length)]} `;
    } else {
      feedback = 'Câu trả lời tốt! ';
    }

    let reply;
    if (nextA) {
      reply = `${feedback}\n\n(${nameA}): "${nextA.text}"`;
      Speech.speak(nextA.text, true);
    } else {
      reply = `${feedback}\n\nBạn đã hoàn thành hội thoại! 🎉 Rất tuyệt vời! Bạn có thể bắt đầu lại hoặc nhập hội thoại mới để luyện tiếp.`;
      document.getElementById('rpStatus').textContent = 'Hội thoại hoàn thành! Thử nhập hội thoại mới để luyện tiếp.';
    }

    addMessage(reply, false);
    context.push({ role: 'ai', text: reply });
  }

  function speakUserInput() {
    const val = document.getElementById('rpInput').value.trim();
    if (val) Speech.speak(val, false);
  }

  return { init, sendMessage, speakUserInput };
})();

// Global wrappers called by HTML onclick
function sendRoleplay()    { Roleplay.sendMessage(); }
function speakUserInput()  { Roleplay.speakUserInput(); }
