// ============================================================
//  data.js — Vocabulary & Grammar Database
//  Thêm từ vựng vào VOCAB_DB, thêm ngữ pháp vào GRAMMAR_DB
// ============================================================

const VOCAB_DB = [
  { word: 'project',     phonetic: '/ˈprɒdʒ.ekt/',   type: 'n.',    meaning: 'dự án, đề án',               example: 'We finished the project on time.' },
  { word: 'finished',    phonetic: '/ˈfɪn.ɪʃt/',     type: 'v.',    meaning: 'đã hoàn thành',               example: 'Have you finished your homework?' },
  { word: 'working',     phonetic: '/ˈwɜː.kɪŋ/',     type: 'v.',    meaning: 'đang làm việc',               example: "She's been working all night." },
  { word: 'excited',     phonetic: '/ɪkˈsaɪ.tɪd/',   type: 'adj.',  meaning: 'hứng thú, phấn khích',        example: "I'm excited about the trip." },
  { word: 'presenting',  phonetic: '/prɪˈzen.tɪŋ/',  type: 'v.',    meaning: 'trình bày',                   example: 'He is presenting his ideas.' },
  { word: 'visuals',     phonetic: '/ˈvɪʒ.u.əlz/',   type: 'n.',    meaning: 'hình ảnh minh họa',           example: 'Add more visuals to your slides.' },
  { word: 'prepared',    phonetic: '/prɪˈpeəd/',      type: 'v.',    meaning: 'đã chuẩn bị',                 example: 'She prepared the report carefully.' },
  { word: 'charts',      phonetic: '/tʃɑːts/',        type: 'n.',    meaning: 'biểu đồ',                     example: 'The charts show the sales data.' },
  { word: 'considered',  phonetic: '/kənˈsɪd.əd/',   type: 'v.',    meaning: 'đã xem xét',                  example: 'Have you considered other options?' },
  { word: 'results',     phonetic: '/rɪˈzʌlts/',     type: 'n.',    meaning: 'kết quả',                     example: 'The results were impressive.' },
  { word: 'deadline',    phonetic: '/ˈded.laɪn/',    type: 'n.',    meaning: 'hạn chót',                    example: 'The deadline is next Friday.' },
  { word: 'meeting',     phonetic: '/ˈmiː.tɪŋ/',     type: 'n.',    meaning: 'cuộc họp',                    example: 'We have a meeting at 9 AM.' },
  { word: 'schedule',    phonetic: '/ˈʃed.juːl/',    type: 'n./v.', meaning: 'lịch trình / sắp xếp lịch',  example: 'Can we schedule a call for tomorrow?' },
  { word: 'feedback',    phonetic: '/ˈfiːd.bæk/',    type: 'n.',    meaning: 'phản hồi',                    example: 'I appreciate your feedback.' },
  { word: 'submit',      phonetic: '/səbˈmɪt/',      type: 'v.',    meaning: 'nộp, gửi',                    example: 'Please submit the report by Monday.' },
  { word: 'review',      phonetic: '/rɪˈvjuː/',      type: 'v./n.', meaning: 'xem xét / bài đánh giá',     example: 'Can you review my essay?' },
  { word: 'suggest',     phonetic: '/səˈdʒest/',     type: 'v.',    meaning: 'đề xuất, gợi ý',              example: 'I suggest we take a break.' },
  { word: 'available',   phonetic: '/əˈveɪ.lə.bəl/', type: 'adj.',  meaning: 'sẵn sàng, rảnh rỗi',         example: 'Are you available on Wednesday?' },
  { word: 'confirm',     phonetic: '/kənˈfɜːm/',     type: 'v.',    meaning: 'xác nhận',                    example: 'Please confirm your attendance.' },
  { word: 'handle',      phonetic: '/ˈhæn.dəl/',     type: 'v.',    meaning: 'xử lý, giải quyết',           example: 'I can handle the presentation.' },
];

const GRAMMAR_DB = [
  {
    name:    'Present Perfect',
    pattern: /\b(have|has|haven't|hasn't|have not|has not)\s+\w+(ed|en|t|ne|wn|ld)\b/gi,
    formula: 'S + have/has + V3 (past participle)',
    tip:     'Dùng để nói về hành động đã xảy ra & còn liên quan đến hiện tại.',
  },
  {
    name:    'Present Perfect Continuous',
    pattern: /\b(have|has)\s+been\s+\w+ing\b/gi,
    formula: 'S + have/has + been + V-ing',
    tip:     'Dùng khi nhấn mạnh hành động đã kéo dài từ quá khứ đến hiện tại.',
  },
  {
    name:    'Look forward to',
    pattern: /\blook\s+forward\s+to\b/gi,
    formula: 'look forward to + V-ing / Noun',
    tip:     '"to" ở đây là giới từ, không phải to-infinitive.',
  },
  {
    name:    'Present Continuous',
    pattern: /\b(am|is|are|'m|'re|'s)\s+\w+ing\b/gi,
    formula: 'S + am/is/are + V-ing',
    tip:     'Dùng cho hành động đang xảy ra tại thời điểm nói.',
  },
  {
    name:    'Already (Present Perfect)',
    pattern: /\balready\b/gi,
    formula: 'S + have/has + already + V3',
    tip:     '"already" thường đặt giữa have/has và động từ chính.',
  },
  {
    name:    'Yes/No Question – Present Perfect',
    pattern: /\b(Have|Has)\s+you\b/gi,
    formula: 'Have/Has + S + V3 + ?',
    tip:     'Đảo Have/Has lên đầu để tạo câu hỏi Yes/No với Present Perfect.',
  },
  {
    name:    'Consider + V-ing',
    pattern: /\bconsider\w*\s+\w+ing\b/gi,
    formula: 'consider + V-ing',
    tip:     '"consider" theo sau bởi V-ing, không dùng to-infinitive.',
  },
  {
    name:    'Simple Past',
    pattern: /\b(was|were|went|got|said|told|knew|came|took|made|gave|found|thought|saw|left|brought)\b/gi,
    formula: 'S + V2 (past simple)',
    tip:     'Dùng cho hành động hoàn thành trong quá khứ tại một thời điểm cụ thể.',
  },
];
